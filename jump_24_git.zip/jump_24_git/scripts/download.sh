#!/bin/bash

dataset_path="https://storage.googleapis.com/kaggle-data-sets/4538/7213/bundle/archive.zip?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=gcp-kaggle-com%40kaggle-161607.iam.gserviceaccount.com%2F20240814%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20240814T223147Z&X-Goog-Expires=259200&X-Goog-SignedHeaders=host&X-Goog-Signature=839667192d0fc15dc47c90e55d69c5ac233a5f0c7d25ed5c1d7eba0a1e0916c26568fbbb523abf54341bad9e63fb6f22520694c795d6be1aeba24e6a6db9a0cdec1d871d00ddbb8571fbb1aeb7f5df1a74df9a5bd35293624c1296481e1312212898c48321c7ffaba7c686af5d37209730b7e9bd782c518cfdcafba1fabc1b62b040048f379cccae9f50c305a6a0cd0a5063af086eb813971748288bbf0915c8f93ae11a62779b0b25212ae024bc9faa2937e695a968d18061b5984dfaf0c8d2b8afc1854138f367a1e8c9dfecce678fd7bfca34b23f684fa4c1b16c063197fd383497b4554bf4457110dca5d1ea69ceeb461bfb84299ef232c16176f9247b3a"

# Get the directory of the current script
script_dir=$(dirname "$(realpath "$0")")

# Determine the parent directory
parent_dir=$(dirname "$script_dir")

# Define the output path in the parent directory
output_path="$parent_dir/market_data.zip"

# Download the dataset to the parent directory
wget -O "$output_path" $dataset_path

# Unzip the downloaded file in the parent directory
unzip "$output_path" -d "$parent_dir"

# Remove the zip file after extraction
rm -rf "$output_path"