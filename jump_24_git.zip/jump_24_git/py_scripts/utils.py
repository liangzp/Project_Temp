import os
import json

import numpy as np
import pandas as pd
import seaborn as sns
import lightgbm as lgb
import matplotlib.pyplot as plt
import plotly.graph_objects as go

from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, Ridge

from functools import partial
from concurrent.futures import ThreadPoolExecutor

rdgn = sns.diverging_palette(240, 10, n = 9, as_cmap=True)

name_changing_dict = {'meta': 'fb'}

with open('../config/basic.json', 'r') as cur:
    basic_config = json.load(cur)

class data_library:
    def __init__(self):
        self.num_workers = 100
        self.INPUT_DIR = '../Data/'
    
    def get_univ_path(self, 
                 name: str
                ):
        """
        :str name can be string w/wo .pq format suffix
        """
        if not name.endswith('.pq'):
            name += '.pq'
        return os.path.join(self.INPUT_DIR, 'univs', name)
    
    def get_stock_path(self,
                      symbol: str
                      ):
        
        return os.path.join(self.INPUT_DIR, 'Stocks', f"{symbol.lower()}.us.txt")
    
    def get_etf_path(self, 
                    symbol: str
                    ):
        return os.path.join(self.INPUT_DIR, 'ETFs', f"{symbol.lower()}.us.txt")
    
    def fetch_univ(self, name):
        univ_path = self.get_univ_path(name)
        return pd.read_parquet(univ_path)
    
    def fetch_symbol(self, symbol):
        symbol, path = symbol.lower().replace('.', '-'), None
        stock_path = self.get_stock_path(symbol)
        etf_path = self.get_etf_path(symbol)
        if os.path.exists(stock_path):
            path = stock_path
        elif os.path.exists(etf_path):
            path = etf_path
        elif symbol in name_changing_dict:
            alt_symbol = name_changing_dict[symbol]
            stock_path = self.get_stock_path(alt_symbol)
            path = stock_path
        if path is not None:
            df = pd.read_csv(path)
            df['Symbol'] = symbol
            return None, df
        else:
            return symbol, None

            
    def fetch_pv(self, univ):
        if isinstance(univ, str):
            err, df = self.fetch_symbol(univ)
        elif isinstance(univ, list):
            with ThreadPoolExecutor(max_workers = self.num_workers) as cur:
                lst = list(cur.map(self.fetch_symbol, univ))
            err = [temp_err for temp_err, _ in lst if temp_err is not None]
            df = pd.concat([temp_df for _, temp_df in lst if temp_df is not None])
        elif isinstance(univ, pd.DataFrame):
            univ = univ.values.flatten().tolist()
            with ThreadPoolExecutor(max_workers = self.num_workers) as cur:
                lst = list(cur.map(self.fetch_symbol, univ))
            err = [temp_err for temp_err, _ in lst if temp_err is not None]
            df = pd.concat([temp_df for _, temp_df in lst if temp_df is not None])
        df = df.reset_index(drop = True)
        return err, df

def sns_hist(df, col, xlabel, ylabel, title, save_path = None):
    hist_config = basic_config['hist']
    keys = ['figsize', 'bins', 'kde']
    print(hist_config)
    for key in keys:
        globals()[key] = hist_config[key]
    fig, ax = plt.subplots(figsize=figsize, dpi = 300)
    sns.histplot(df[col], bins=bins, kde=kde, ax=ax)
    plt.title(title, fontsize = 20)
    plt.xlabel(xlabel, fontsize = 16)
    plt.ylabel(ylabel, fontsize = 16)
    ax.tick_params(axis='both', which='major', labelsize=14)
    plt.tight_layout()
    if save_path is not None:
        plt.savefig(f'../figures/{save_path}.png')
    plt.show()
    
def plotly_line(df, xcol, ycols, title, xaxis_title=None, yaxis_title=None, opacity=1.0, save_name=None):
    # Create the plot
    fig = go.Figure()
    
    if isinstance(ycols, str):
        ycols = [ycols]

    for ycol in ycols:
        fig.add_trace(go.Scatter(
            x=df[xcol],
            y=df[ycol],
            mode='lines',
            name= ycol,
            opacity=opacity  # Set the opacity here
        ))

    if yaxis_title is None:
        # Update layout
        fig.update_layout(
            title=title,
            xaxis_title=xcol,
            yaxis_title=ycols[0]
        )
    else:
        # Update layout
        fig.update_layout(
            title=title,
            xaxis_title=xcol,
            yaxis_title=yaxis_title
        )
    
    # Show the plot
    fig.show()

    # Save the figure if save_name is provided
    if save_name is not None:
        fig.write_image(f"../figures/{save_name}.png")
    
    
def beautify(df, title):
    return df.style.background_gradient(axis = 0, cmap=rdgn).set_caption(title)


### axuliary functions

def eval(df, y_pred_cols, label = 'f_1d_ret_disp_log_diff', mode = 'full', metrics = 'corr', EPS = 1e-4):
    from sklearn.metrics import mean_absolute_error, mean_squared_error 
    def RMSPE(y, y_pred):
        return np.sqrt(np.nanmean(np.power((y - y_pred)/(y+EPS), 2)))
    
    def MSE(y, y_pred):
        return np.nanmean(np.power(y - y_pred, 2))
    
    def corr(y_true, y_pred):
        return (y_true * y_pred).sum() / np.sqrt(y_pred.T.dot(y_pred)) #np.corrcoef(y_true, y_pred)[0][1]
    
    label_df = pd.read_parquet('../Data/Panel/SP500_Label.pq') # need to change
    if label not in label_df.columns:
        label_df[label] = label_df['_'.join(label.split('_')[:-1])].diff().fillna(0)
    
    y = label_df[['Date', label]]
    
    if not isinstance(y_pred_cols, list):
         y_pred_cols = [y_pred_cols]
            
    if df['Date'].dtype != 'datetime64[ns]':
        df['Date'] = pd.to_datetime(df['Date'])
        df = df.sort_values('Date')

    if y['Date'].dtype != 'datetime64[ns]':
        y['Date'] = pd.to_datetime(y['Date'])
        y = y.sort_values('Date')
        
    eval_df = df[['Date'] +  y_pred_cols].merge(y, on = 'Date').fillna(0)
    eval_df = eval_df[eval_df['Date']< pd.to_datetime('2015-01-01')] # prevent looking at oos data
    eval_df['Year'] = eval_df['Date'].dt.strftime("%Y")
    eval_df['YM'] = eval_df['Date'].dt.strftime("%Y_%m")
    years, years_month = eval_df['Year'].unique(), eval_df['YM'].unique()
    
    full_loss_dict, year_loss_dict, ym_loss_dict = dict(), dict(), dict()
    for y_pred_col in y_pred_cols:
        eval_func = locals()[metrics]
        full_loss = eval_func(y_true=eval_df[label], y_pred=eval_df[y_pred_col])
        year_loss = eval_df.groupby('Year').apply(lambda group: eval_func(y_true=group[label], y_pred=group[y_pred_col]))
        year_month_loss = eval_df.groupby('YM').apply(lambda group: eval_func(y_true=group[label], y_pred=group[y_pred_col]))        
        full_loss_dict[y_pred_col] = [full_loss]
        year_loss_dict[y_pred_col] = year_loss
        ym_loss_dict[y_pred_col] = year_month_loss        
        
    full_loss_df = pd.DataFrame(full_loss_dict)
    year_loss_df = pd.DataFrame(year_loss_dict, index = years)
    ym_loss_dict = pd.DataFrame(ym_loss_dict, index = years_month)    
    return full_loss_df, year_loss_df, ym_loss_dict

def rolling_fit(df, feature_cols, model_type, label = 'f_1d_ret_disp_log_diff', sample_size_year = 5, aux_cols = None, sharpe_threshold = 3):
    label_df = pd.read_parquet('../Data/Panel/SP500_Label.pq') # need to change
    if label not in label_df.columns:
        label_df[label] = label_df['_'.join(label.split('_')[:-1])].diff().fillna(0)
    
    y = label_df[['Date', label]]
    
    if not isinstance(feature_cols, list):
         feature_cols = [feature_cols]
            
    df = df[['Date'] + feature_cols + aux_cols].merge(y, on = 'Date').fillna(0) if aux_cols is not None else df[['Date'] + feature_cols].merge(y, on = 'Date').fillna(0)
    
    # Ensure the dataframe is sorted by date
    df = df.sort_values(by='Date')
    
    # Get the first and last year in the dataframe
    start_year = df['Date'].dt.year.min()
    end_year = df['Date'].dt.year.max()
    
    # Initialize lists to store results
    years = []
    mse_list = []
    predictions = []
    feature_importance_lst = []
    
    # Loop through each year in the range
    for year in range(start_year + sample_size_year, end_year + 1):
        train = df[(df['Date'].dt.year >= year - sample_size_year) & (df['Date'].dt.year < year)].copy()

        if isinstance(feature_cols, list) and len(feature_cols)>3:
            corr_df = eval(train, feature_cols)[-1]
            sharpe_df = (corr_df.mean()/corr_df.std() * 16)
            sel_feature = sharpe_df[(sharpe_df>sharpe_threshold) | (sharpe_df<-sharpe_threshold)].index.tolist()
        else:
            sel_feature = feature_cols
        if model_type == 'Linear':
            # Define the training and testing sets
            test = df[df['Date'].dt.year == year].copy()
            years.append(year)
        
            # Standardize the features
            scaler = StandardScaler()
            X_train = np.nan_to_num(scaler.fit_transform(train[sel_feature]), 0, 0, 0)
            X_test = np.nan_to_num(scaler.transform(test[sel_feature]), 0, 0, 0)

            # Fit the linear model
            params = basic_config["fitting"]["Ridge"]
            model = Ridge(alpha = params['alpha'])
            model.fit(X_train, train[label])
            y_pred = model.predict(X_test)
            
            temp_df = pd.DataFrame(model.coef_.reshape(1,-1), columns = sel_feature)
            feature_importance_lst.append(temp_df)
        elif model_type == 'LGB':
            # Define the training and testing sets
            sel_feature += aux_cols if aux_cols else []
            train = df[(df['Date'].dt.year >= year - sample_size_year) & (df['Date'].dt.year < year)].copy()
            valid = df[(df['Date'].dt.year >= year - 1) & (df['Date'].dt.year < year)].copy()
            test = df[df['Date'].dt.year == year].copy()
            years.append(year)

            X_train, y_train, X_valid, y_valid, X_test, y_test = train[sel_feature], train[label], valid[sel_feature], valid[label], test[sel_feature], test[label]
            # Create the LightGBM dataset
            train_data = lgb.Dataset(X_train, label=y_train)
            valid_data = lgb.Dataset(X_valid, label=y_valid, reference=train_data)

            # Set the parameters
            # params = {
            #     'objective': 'regression',
            #     'metric': 'mse',
            #     'boosting_type': 'gbdt',
            #     'num_leaves': 8,
            #     'learning_rate': 0.05,
            #     'feature_fraction': 0.2,
            #     'max_depth': 2,
            #     'n_estimators': 500
            # }
            params = basic_config["fitting"]["LGB"]

            # Train the model
            model = lgb.train(params, train_data, valid_sets=[train_data, valid_data], num_boost_round=100, 
                             callbacks=[lgb.early_stopping(stopping_rounds=3)]
                             )
            
            temp_df = pd.DataFrame(model.feature_importance(importance_type='split').reshape((1,-1)), columns = sel_feature)
            feature_importance_lst.append(temp_df)
            
            # Predict and evaluate
            y_pred = model.predict(X_test, num_iteration=model.best_iteration)

        feature_importance_df = pd.concat(feature_importance_lst).fillna(0).mean()
        # Predict and calculate MSE
        # mse = mean_squared_error(test[label], y_pred)
        mse = test[label].T.dot(y_pred) / np.sqrt(y_pred.T.dot(y_pred))
        
        # Store results
        mse_list.append(mse)
        predictions.extend(y_pred)
    
    return years, mse_list, predictions, feature_importance_df