import os
import numpy as np
import pandas as pd

# Get the current working directory (assuming the notebook is in the same directory as the file)
current_directory = os.getcwd()

# Get the parent directory
parent_directory = os.path.dirname(current_directory)

import sys
sys.path.append(parent_directory)
from py_scripts.utils import data_library

def main():
    dls = data_library()
    univ = dls.fetch_univ("SP500_Clean")
    err, df = dls.fetch_pv(univ)

    prc_cols = ['Open', 'High', 'Low', 'Close']

    df['ref_price'] = df[prc_cols].apply(lambda x: np.median(x), axis=1)

    # need to run the code twice
    for _ in range(2):
        for col in ['Open', 'High', 'Low', 'Close']:
            err_ind = np.where((df[col] < df['ref_price']) & (df[col] < df['ref_price']*0.2))[0]
            df.loc[err_ind, col] *= 10
            print(f"fix {col} column with {len(err_ind)} rows")

    # sanity check
    # as we are mainly interest in the Close price, we can add some sanity check
    # 1. Close price should be (1) positive (2) within high and low (3) the daily return should be in a reasonable range

    # 1. Close price should be positive
    assert df[df['Close'] > 0].shape[0] == df.shape[0]

    # 2. Close price should be within high and low
    assert df[(df['Close'] >= df['Low']) & (df['Close'] <= df['High'])].shape[0] == df.shape[0]

    df['Date'] = pd.to_datetime(df['Date'])
    df.to_parquet("../Data/Panel/SP500_Clean.pq")

if __name__ == "__main__":
    main()