import os
import sys
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import plotly.graph_objects as go

from itertools import combinations


# Get the current working directory (assuming the notebook is in the same directory as the file)
current_directory = os.getcwd()
# Get the parent directory
parent_directory = os.path.dirname(current_directory)
sys.path.append(parent_directory)

from py_scripts.utils import sns_hist, plotly_line, beautify, eval, rolling_fit


def main():
    def fe_basic(df):
        df['b_in_ret'] = np.log(df['Close']/df['Open']).fillna(0)
        df['b_ov_ret'] = np.log(df['Open']/df.groupby('Symbol')['Close'].shift()).fillna(0)
        df['b_1d_ret'] = np.log(df['Close']/df.groupby('Symbol')['Close'].shift()).fillna(0)

        rets_col = ['b_in_ret', 'b_ov_ret', 'b_1d_ret']
        ret_disp_lst, rets_disp_col = [], []

        for ret in rets_col:
            ret_disp_lst.append(df.groupby('Date')[ret].std().rename(f"{ret}_disp"))
            rets_disp_col.append(f'{ret}_disp')
            
        feature_df = pd.concat(ret_disp_lst, axis = 1).reset_index()

        for ret in rets_col:
            feature_df[f'al.{ret}_disp_log_diff'] = np.log(feature_df[f'{ret}_disp']).diff().replace([np.inf, -np.inf], np.nan).fillna(0)

        for shift in range(1, 6):
            for ret in rets_col:
                feature_df[f'al.{ret}_disp_log_diff_{shift}d'] = feature_df[f'al.{ret}_disp_log_diff'].shift(shift)

        return feature_df

    def fe_stat(df, feature_df):
        def rolling_mean(df, col, window):
            return df.groupby('Date')[col].mean().rolling(window = window).mean().fillna(0).values

        def rolling_std(df, col, window):
            return df.groupby('Date')[col].std().rolling(window = window).mean().fillna(0).values

        def rolling_quantile(df, col, window, quantile):
            return df.groupby('Date')[col].quantile(quantile).rolling(window = window).mean().fillna(0).values

        def rolling_skew(df, col, window):
            return df.groupby('Date')[col].skew().rolling(window = window).mean().fillna(0).values

        df = df.sort_values('Date')
        windows = [1, 5, 20, 60]

        # return features
        for ret_type in ['in', 'ov', '1d']:
            for window in windows:
                feature_df[f'al.b_{ret_type}_ret_mean'] = rolling_mean(df, f'b_{ret_type}_ret', window)
                feature_df[f'bl.b_{ret_type}_ret_std'] = rolling_std(df, f'b_{ret_type}_ret', window)
                
            
            for short_window, long_window in combinations(windows, 2):
                feature_df[f'al.b_{ret_type}_ret_mean_{short_window}_{long_window}'] = rolling_mean(df, f'b_{ret_type}_ret', short_window) - rolling_mean(df, f'b_{ret_type}_ret', long_window)
                feature_df[f'al.b_{ret_type}_ret_std_{short_window}_{long_window}'] = rolling_std(df, f'b_{ret_type}_ret', short_window) - rolling_std(df, f'b_{ret_type}_ret', long_window)
                feature_df[f'al.b_{ret_type}_ret_skew_{short_window}_{long_window}'] = rolling_skew(df, f'b_{ret_type}_ret', short_window) - rolling_skew(df, f'b_{ret_type}_ret', long_window)
            
                for quantile in [0.1, 0.3, 0.5, 0.7, 0.9]:
                    feature_df[f'al.b_{ret_type}_ret_quantile_{quantile}_{short_window}_{long_window}'] = rolling_quantile(df, f'b_{ret_type}_ret', short_window, quantile) - rolling_quantile(df, f'b_{ret_type}_ret', long_window, quantile)

            for lag in range(1, 8):
                feature_df[f'al.{ret_type}_disp_log_diff_{lag}'] = feature_df[f'al.{ret_type}_disp_log_diff'].shift(lag).fillna(0)
                
        for short_window, long_window in combinations(windows, 2):
            feature_df[f'al.b_{ret_type}_volume_mean_{short_window}_{long_window}'] = rolling_mean(df, 'Volume', short_window) - rolling_mean(df, 'Volume', long_window)
            feature_df[f'al.b_{ret_type}_volume_std_{short_window}_{long_window}'] = rolling_std(df, 'Volume', short_window) - rolling_std(df, 'Volume', long_window)
            feature_df[f'al.b_{ret_type}_volume_skew_{short_window}_{long_window}'] = rolling_skew(df, 'Volume', short_window) - rolling_skew(df, 'Volume', long_window)
            
        for short_window, long_window in combinations(windows, 2):
            feature_df[f'al.b_{ret_type}_volume_mean_ratio_{short_window}_{long_window}'] = np.nan_to_num(np.log(rolling_mean(df, 'Volume', short_window)/rolling_mean(df, 'Volume', long_window)))
            feature_df[f'al.b_{ret_type}_volume_std_ratio_{short_window}_{long_window}'] = np.nan_to_num(np.log(rolling_std(df, 'Volume', short_window)/rolling_std(df, 'Volume', long_window)))

        for window in windows:
            for ret_type in ['in', 'ov', '1d']:
                feature_df[f'al.b_{ret_type}_zscore'] = np.nan_to_num((rolling_mean(df, f'b_{ret_type}_ret', 1) - rolling_mean(df, f'b_{ret_type}_ret', window)) / rolling_std(df, f'b_{ret_type}_ret', window), 0, 0, 0)
                feature_df[f'al.b_{ret_type}_zscore_sig'] = np.where(feature_df[f'al.b_{ret_type}_zscore'] > 3, 1, np.where(feature_df[f'al.b_{ret_type}_zscore'] < -3, -1, 0))
            feature_df[f'al.b_volume_zscore'] = np.nan_to_num((rolling_mean(df, 'Volume', 1) - rolling_mean(df, 'Volume', window)) / rolling_std(df, 'Volume', window), 0, 0, 0)
    
    df = pd.read_parquet("../Data/Panel/SP500_CleanRet.pq")
    feature_df = fe_basic(df)
    feature_df = fe_stat(df, feature_df)

    mse_df = pd.DataFrame()
    # alpha_cols = sel_cols[0]
    alpha_cols = 'al.b_ov_ret_quantile_0.3_1_20'
    years, mse_list, predictions, feature_importance_df = rolling_fit(feature_df, alpha_cols, model_type = 'Linear')
    mse_df['cf.' + alpha_cols] = mse_list

    alpha_cols = 'al.b_volume_zscore'
    years, mse_list, predictions, feature_importance_df = rolling_fit(feature_df, alpha_cols, model_type = 'Linear')
    mse_df['cf.' + alpha_cols] = mse_list

    alpha_cols = 'al.b_in_ret_std_5_60'
    years, mse_list, predictions, feature_importance_df = rolling_fit(feature_df, alpha_cols, model_type = 'Linear')
    mse_df['cf.' + alpha_cols] = mse_list

    alpha_cols = [col for col in feature_df.columns if col.startswith('al.')]
    years, mse_list, predictions, feature_importance_dfs = rolling_fit(feature_df, alpha_cols, model_type = 'Linear', sharpe_threshold = 2)
    mse_df['cf.linear'] = mse_list

    alpha_cols = [col for col in feature_df.columns if col.startswith('al.')]
    years, alpha_mse_list, predictions, feature_importance_df = rolling_fit(feature_df, alpha_cols, model_type = 'LGB', aux_cols = None)
    mse_df['cf.lgb_wo_aux'] = alpha_mse_list

    alpha_cols = [col for col in feature_df.columns if col.startswith('al.')]
    beta_cols = [col for col in feature_df.columns if col.startswith('bl.')]
    years, alpha_mse_list, predictions, feature_importance_df = rolling_fit(feature_df, alpha_cols, model_type = 'LGB', aux_cols = beta_cols)
    mse_df['cf.lgb'] = alpha_mse_list


    ## in sample
    cum_mse_df = mse_df.cumsum()
    cum_mse_df['year'] = years
    cum_mse_df = cum_mse_df[cum_mse_df['year']<=2015]
    cf_cols = [col for col in cum_mse_df.columns if col.startswith('cf.')]
    plotly_line(cum_mse_df, 'year', cf_cols, title = 'Comparison of Fitting', xaxis_title= 'Years', yaxis_title= 'Cumulative FR', opacity=1.0)

    os.path.makedirs('../Data/Results', exist_ok = True)
    mse_df.to_csv('../Data/Results/FR_is.csv')


    ## is+oos 
    cum_mse_df = mse_df.cumsum()
    cum_mse_df['year'] = years
    cf_cols = [col for col in cum_mse_df.columns if col.startswith('cf.')]
    plotly_line(cum_mse_df, 'year', cf_cols, title = 'Comparison of Fitting', xaxis_title= 'Years', yaxis_title= 'Cumulative FR', opacity=1.0)
    mse_df.to_csv('../Data/Results/FR_full.csv')