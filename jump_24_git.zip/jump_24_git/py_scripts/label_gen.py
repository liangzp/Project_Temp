import numpy as np
import pandas as pd

def main():
    df = pd.read_parquet('../Data/Panel/SP500_CleanRet.pq')

    df['b_in_ret'] = np.log(df['Close']/df['Open']).fillna(0)
    df['b_ov_ret'] = np.log(df['Open']/df.groupby('Symbol')['Close'].shift()).fillna(0)
    df['b_1d_ret'] = np.log(df['Close']/df.groupby('Symbol')['Close'].shift()).fillna(0)

    df['f_ov_ret'] = np.log(df.groupby('Symbol')['Open'].shift(-1)/df['Close']).fillna(0)
    df['f_in_ret'] = np.log(df.groupby('Symbol')['Close'].shift(-1)/df.groupby('Symbol')['Open'].shift(-1)).fillna(0)
    df['f_1d_ret'] = np.log(df.groupby('Symbol')['Close'].shift(-1)/df['Close']).fillna(0)

    df.sort_values('Date', inplace = True)
    df = df.reset_index(drop = True)

    rets_col = ['b_in_ret', 'b_ov_ret', 'b_1d_ret', 'f_in_ret', 'f_ov_ret', 'f_1d_ret']
    rets_disp_col = list()
    ret_disp = pd.DataFrame({'Date': sorted(pd.to_datetime(df.Date.unique()))})

    ret_disp_lst = []
    for ret in rets_col:
        ret_disp_lst.append(df.groupby('Date')[ret].std().rename(f"{ret}_disp"))
        rets_disp_col.append(f'{ret}_disp')

    ret_disp = pd.concat(ret_disp_lst, axis = 1).reset_index()

    for ret in rets_col:
        ret_disp[f'{ret}_disp_log'] = np.log(ret_disp[f'{ret}_disp'])

    for ret in rets_col:
        ret_disp[f'{ret}_disp_log_diff'] = ret_disp[f'{ret}_disp_log'].diff().replace([np.inf, -np.inf], np.nan).fillna(0)

    ret_disp.to_parquet('../Data/Panel/SP500_Label.pq')

if __name__ == "__main__":
    main()