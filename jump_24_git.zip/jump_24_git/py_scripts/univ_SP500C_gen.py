import os
import pandas as pd

def main():
    # Get the current working directory (assuming the notebook is in the same directory as the file)
    current_directory = os.getcwd()

    # Get the parent directory
    parent_directory = os.path.dirname(current_directory)

    import sys
    sys.path.append(parent_directory)
    from py_scripts.utils import data_library

    dls = data_library()
    univ = dls.fetch_univ("SP500")
    err, df = dls.fetch_pv(univ)

    # Assuming df is your DataFrame
    # Ensure the 'Date' column is in datetime format
    df['Date'] = pd.to_datetime(df['Date'])

    # Group by 'symbol' and aggregate to find the min and max dates
    summary_df = df.groupby('Symbol')['Date'].agg(['min', 'max']).reset_index()

    # Rename the columns for clarity
    summary_df.columns = ['symbol', 'start_date', 'end_date']
    summary_df.sort_values(['end_date', 'start_date'], inplace = True)
    summary_df['sample_size'] = (summary_df['end_date'] - summary_df['start_date']).dt.days
    pd.DataFrame({"univ": summary_df[(summary_df['sample_size']>=1260)]['symbol'].tolist()}).to_parquet('../Data/univs/SP500_Clean.pq')

if __name__ == "__main__":
    main()